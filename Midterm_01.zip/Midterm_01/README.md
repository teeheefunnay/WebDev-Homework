Link to the blog: 
http://sites.bxmc.poly.edu/~tiffanyshu/PPO/?page_id=143
Link to the site:
http://sites.bxmc.poly.edu/~tiffanylieu/Tiff_Midterm/Midterm_01/drinks.html